class MTBParserException(Exception):
    """Raise in case the parsing goes wrong"""

class MTBSnvFormatException(Exception):
    """Raise in case the SNV entry is of wrong format"""